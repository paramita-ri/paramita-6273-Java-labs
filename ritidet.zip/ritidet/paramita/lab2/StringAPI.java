package ritidet.paramita.lab2;

public class StringAPI {
    public static void main(String[] args) {
        String schoolName = args[0] ; 
        String university = "University" ;
        String college = "College" ;
        if (schoolName.equalsIgnoreCase(university)) {
            System.out.println(schoolName + " is a " + university);
        }
        else if (schoolName.equalsIgnoreCase(college)) {
            System.out.println(schoolName + " is a " + college);
        }
    }
}
